This code contains all the problems found in the given of this project, to run it, you have the following options :
Each problem can be run for respective values of the following parameters:

NB : the coefficients for each problem can be found in the report.

"pb" - ligne 527 - choose the problem you want to run 
"i" - ligne 525 - stabilization fopr the convection problem
"mExp" - ligne 526 - change the stabilization term's power
"EF_Pk" - ligne 520 - finite element type -P1 or P2 or P3


Problem 1: PURE REACTION PROBLEM
parameters :
pb = 1 
i & mExp can take any values.
EF_Pk : choose the Pk_FEM.


Problem 2: ISOTROPIC DIFFUSION PROBLEM
parameters :
pb = 2
i & mExp can take any values.
EF_Pk : choose the Pk_FEM.

Problems 3-4-5: ANISOTROPIC DIFFUSION PROBLEM
parameters :
pb = 3,4,5
i & mExp can take any values.
EF_Pk : choose the Pk_FEM.


Problem 6: CONVECTION PROBLEM
parameters :
pb = 6
i=0 for no stabilization
i=1 to stabilize the problem - WHEN YOU SET i=1 IT IS MANDATORY TO CHOOSE mExp
mExp = 1 or 2 or 3. 
EF_Pk : choose the Pk_FEM.


Problem 7: CONVECTION-REACTION-DIFFUSION PROBLEM
parameters :
pb = 7
i & mExp can take any values.
EF_Pk : choose the Pk_FEM.

-----------------------------------------------------------------------------

This zipped folder contains a python script "convergence_curve_convection_pb" , this script contains a parser, 
run "python convergence_curve_convection_pb.py -h" to get the options to run the script, 

!!!!!! YOU HAVE TO UN-COMMENT THE PART TO SAVE THE RESULTS INTO A CSV FILE FOR THE CONVECTION PROBLEM, RUN THE SCILAB SOLVER FOR EACH "m", AND FOR EACH Pk, 
TO HAVE THE NECESSARY FILES TO PLOT USING THE PYTHON SCRIPT !!!!!! 
